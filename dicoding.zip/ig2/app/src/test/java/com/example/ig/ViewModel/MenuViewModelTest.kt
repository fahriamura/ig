package com.example.ig.ViewModel

internal class MenuViewModelTest {

    @org.junit.jupiter.api.Test
    fun getGithubUser() {
    }

    @org.junit.jupiter.api.Test
    fun getFollower() {
    }

    @org.junit.jupiter.api.Test
    fun getFollowing() {
    }

    @org.junit.jupiter.api.Test
    fun isLoading() {
    }

    @org.junit.jupiter.api.Test
    fun testGetGithubUser() {
    }

    @org.junit.jupiter.api.Test
    fun getGithubDetail() {
    }

    @org.junit.jupiter.api.Test
    fun getGithubFollowers() {
    }

    @org.junit.jupiter.api.Test
    fun getGithubFollowing() {
    }
}
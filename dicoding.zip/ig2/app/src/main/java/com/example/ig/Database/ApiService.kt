package com.example.ig.Database

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @GET("search/users")
    @Headers("Authorization: token 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")
    fun getSearchUser(@Query("q") query: String):Call<UserResponse>

    @GET("users/{username}")
    @Headers("Authorization: token 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")
    fun getUserDetail(@Path("username") username: String):Call<ItemsItem>

    @GET("users/{username}/followers")
    @Headers("Authorization: token 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")
    fun getUserFollowers(@Path("username") username: String):Call<ArrayList<ItemsItem>>

    @GET("users/{username}/com.example.ig.following")
    @Headers("Authorization: token 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")
    fun getUserFollowing(@Path("username") username: String):Call<ArrayList<ItemsItem>>
}